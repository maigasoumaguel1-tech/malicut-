/* MaliCut V8 - Touch / Navigation Fix */
(function () {
  "use strict";

  function showPage(id) {
    if (!id) return false;
    var target = document.getElementById(id);
    if (!target) return false;

    document.querySelectorAll("[data-page], .page, .screen").forEach(function (el) {
      el.hidden = el.id !== id;
      el.style.display = el.id === id ? "" : "none";
    });

    target.hidden = false;
    target.style.display = "";
    target.scrollIntoView({behavior:"smooth", block:"start"});
    return true;
  }

  function action(name, el) {
    if (!name) return false;

    if (typeof window[name] === "function") {
      try { window[name](el); return true; }
      catch (err) { console.error("MaliCut action error:", name, err); }
    }

    var routes = {
      home:["home","accueil"], accueil:["home","accueil"],
      models:["models","modeles","modèles"], modeles:["models","modeles","modèles"],
      create:["create","creer","créer"], creer:["create","creer","créer"],
      community:["community","communaute","communauté"], communaute:["community","communaute","communauté"],
      profile:["profile","profil"], profil:["profile","profil"],
      notifications:["notifications","alertes"], alertes:["notifications","alertes"],
      settings:["settings","parametres","paramètres"], parametres:["settings","parametres","paramètres"]
    };

    var ids = routes[String(name).toLowerCase()] || [name];
    for (var i=0; i<ids.length; i++) {
      if (document.getElementById(ids[i])) return showPage(ids[i]);
      var p = document.querySelector('[data-page="' + ids[i] + '"]');
      if (p && p.id) return showPage(p.id);
    }
    return false;
  }

  function handle(el) {
    var nav = el.getAttribute("data-nav") || el.getAttribute("data-page-target");
    var act = el.getAttribute("data-action");
    var href = el.getAttribute("data-href");

    if (nav && (action(nav, el) || showPage(nav))) return;
    if (act && action(act, el)) return;

    if (href && href !== "#") {
      if (href.charAt(0) === "#" && showPage(href.slice(1))) return;
      if (href.charAt(0) !== "#") window.location.href = href;
    }
  }

  document.addEventListener("click", function(e) {
    var el = e.target.closest("button,[role='button'],[data-action],[data-nav],[data-page-target],.nav-item,.menu-item,.tab");
    if (el) handle(el);
  }, true);

  document.addEventListener("touchend", function(e) {
    var el = e.target.closest("button,[role='button'],[data-action],[data-nav],[data-page-target],.nav-item,.menu-item,.tab");
    if (!el) return;
    handle(el);
  }, {capture:true, passive:true});

  document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll("button,[role='button'],.nav-item,.menu-item,.tab").forEach(function(el) {
      el.style.pointerEvents = "auto";
      el.style.touchAction = "manipulation";
      if (el.tagName === "BUTTON") el.disabled = false;
    });

    document.querySelectorAll(".overlay,.backdrop").forEach(function(el) {
      if (!el.querySelector("button,a,input,[role='button']")) el.style.pointerEvents = "none";
    });

    console.log("MaliCut V8 Touch Fix chargé");
  });
})();
